<?php

namespace Modules\Lesson\Entities;

use Illuminate\Database\Eloquent\Model;

class SmLessonDetails extends Model
{
    protected $fillable = [];
}
