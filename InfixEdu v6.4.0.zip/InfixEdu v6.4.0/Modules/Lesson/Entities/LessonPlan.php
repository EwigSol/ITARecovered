<?php

namespace Modules\Lesson\Entities;

use Illuminate\Database\Eloquent\Model;

class LessonPlan extends Model
{
    protected $fillable = [];
}
