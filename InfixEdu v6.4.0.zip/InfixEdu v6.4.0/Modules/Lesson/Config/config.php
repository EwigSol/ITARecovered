<?php

return [
    'name' => 'Lesson'
];
