<?php

return [
    'name' => 'XenditPayment'
];
