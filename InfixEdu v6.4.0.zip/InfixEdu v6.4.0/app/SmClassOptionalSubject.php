<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SmClassOptionalSubject extends Model
{
    // protected $fillable = [];
    protected $table="sm_class_optional_subject";

    
}

