<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AbcTest extends Model
{
    protected $fillable  = ['name'];
}
